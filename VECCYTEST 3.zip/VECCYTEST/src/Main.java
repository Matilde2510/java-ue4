import at.fhhgb.mtd.gop.veccy.shapes.Rectangle;

public class Main {
    public static void main(String[] args) {

        Rectangle rect = new Rectangle(0,0,2000, 1000);


    }
}