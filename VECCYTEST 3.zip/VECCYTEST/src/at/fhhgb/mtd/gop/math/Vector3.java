package at.fhhgb.mtd.gop.math;

public class Vector3 {
    private double[] values;
    // Initialisiert values mit { 0.0, 0.0, 1.0 }
    public Vector3() {
        //gli diciamo: crea un nuovo vettore di double con questi elementi
        values = new double[] {0.0, 0.0, 1.0}; //values = è UN ARRAY DI DOUBLE -> VETTORE ED ARRAY SONO LA STESSA COSA
    }

    // Initialisiert this.values mit dem Parameter values (kopieren Sie die Werte!)
    public Vector3(double[] values) { //
        this.values = new double[3]; // crea tre celle di tipo double
        for (int e = 0; e < 3; e++){ // entra da zero, finisci a tre
            this.values[e] = values[e]; // copia l'elemento di values alla posizione e dentro a this.values posiione e
        }
    }

    // Initialisiert this.values mit den values aus dem Parameter vector
    // (verwenden Sie this()!)
    public Vector3(Vector3 vector) {
        this(vector.values); // cosi non devo copiarlo due volte
        // cosi posso fare due costruzioni, sto chiamando il metodo di prima quello su
        // nel caso venisse passato un vettore lo copiamo
        //chiedi se dobbiamo creare altre tre celle o se posso fare direttamente cosi
    }

    // Returniert die Instanzvariable values
    public double[] getValues() {
        return values;
    }
}
