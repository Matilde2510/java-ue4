package at.fhhgb.mtd.gop.math;

public class Matrix3 { //matrice = array
    private double[][] values;
    // Initialisiert values als Einheitsmatrix
    // 1.0 0.0 0.0
    // 0.0 1.0 0.0
    // 0.0 0.0 1.0
    public Matrix3() { // crea una matrice con questi valori
        values = new double[][]{
                {1.0, 0.0, 0.0},
                {0.0, 1.0, 0.0},
                {0.0, 0.0, 1.0}};
    }
    // Initialisiert this.values mit dem Parameter values (kopieren Sie die Werte!)
    public Matrix3(double[][] values) {
        this.values = new double[3][3]; // crea tre celle di tipo double

        for (int y = 0; y < 3; y++)
            for (int x = 0; x < 3; x++){ // entra da zero, finisci a tre
                this.values[y][x] = values[y][x]; // copia l'elemento di values alla posizione e dentro a this.values posiione e
            }
    }
    // Initialisiert this.values mit den values aus dem Parameter matrix

    // (Tipp: Verwenden Sie this()!)
    public Matrix3(Matrix3 matrix) { //copiamo i valori della matrice dentro a this.values
        this(matrix.values);
    }

    // Implementieren Sie eine Matrixmultiplikation und geben Sie eine neue Matrix3
    // Instanz mit dem Ergebnis zurück
    public Matrix3 mult(Matrix3 matrix) { //

        double[][] res = new double[3][3]; // crea una matrice 3x3 che contiene il risultato

        for(int i=0; i < 3; i++){
            for(int j=0; j < 3; j++){
                for (int k = 0; k < 3; k++){
                    double calc = this.values[j][k] * matrix.values[k][i]; //prendiamo la riga k della prima matrice this. values
                    // e la moltiplichiamo con la colonna matrix i
                    res[i][j] += calc; //sommiamo il risultato -> res = risultato
                }
            }
        }
        return new Matrix3(res);
    }

    // Implementieren Sie eine Multiplikation Matrix3 * Vector3 und geben Sie eine // neue Vector3 Instanz mit dem Ergebnis zurück
    public Vector3 mult(Vector3 vector) {
        double[] res = new double[3]; // creo un vettore di dimensione 3
        //li prendo una volta, li slavo dentro values e li uso dopo cosi posso andare piu veloce
        double[] vector_values = vector.getValues(); //prendiamo i valori del vettore Vector

        for(int i=0; i < 3; i++){
            for(int j=0; j < 3; j++){
                    double calc = this.values[i][j] * vector_values[j];
                    res[i] += calc;
            }
        }
        return new Vector3(res);
    }
    // Returniert die Instanzvariable values
    public double[][] getValues() {
        return values;
    }
}

    /**public static Matrix3 createTranslation(int deltaX, int deltaY) {
        Matrix3 translationMatrix = new Matrix3();
        translationMatrix.values[0][2] = deltaX;
        translationMatrix.values[1][2] = deltaY;
        return translationMatrix;
    }

    public static Matrix3 createRotation(double radians) {
        Matrix3 rotationMatrix = new Matrix3();
        double cos = Math.cos(radians);
        double sin = Math.sin(radians);
        rotationMatrix.values[0][0] = cos;
        rotationMatrix.values[0][1] = -sin;
        rotationMatrix.values[1][0] = sin;
        rotationMatrix.values[1][1] = cos;
        return rotationMatrix;
    }

    public static Matrix3 createHorizontalMirroring() {
        Matrix3 mirrorMatrix = new Matrix3();
        mirrorMatrix.values[0][0] = -1;
        return mirrorMatrix;
    }

    public static Matrix3 createVerticalMirroring() {
        Matrix3 mirrorMatrix = new Matrix3();
        mirrorMatrix.values[1][1] = -1;
        return mirrorMatrix;
    }

    public static Matrix3 createScaling(double factorX, double factorY) {
        Matrix3 scalingMatrix = new Matrix3();
        scalingMatrix.values[0][0] = factorX;
        scalingMatrix.values[1][1] = factorY;
        return scalingMatrix;
    }
}**/


