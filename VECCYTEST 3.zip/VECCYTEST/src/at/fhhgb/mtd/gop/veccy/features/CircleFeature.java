package at.fhhgb.mtd.gop.veccy.features;

import at.fhhgb.mtd.gop.veccy.model.CanvasModel;
import at.fhhgb.mtd.gop.veccy.model.NamedFeature;
import at.fhhgb.mtd.gop.veccy.shapes.Circle;

public class CircleFeature implements NamedFeature {

    private CanvasModel model;

    private Circle currentCircle;
    private int originX1;
    private int originY1;

    private boolean drawCircle = false;

    private int distance;

    public CircleFeature(CanvasModel model) {
        this.model = model;
        originX1 = 0;
        originY1 = 0;
        distance = 0;
    }

    @Override
    public String getName() {
        return "Circle";
    }

    @Override
    public void onSelect() {
        drawCircle = true;
    }

    @Override
    public void onDeselect() { drawCircle = false; currentCircle = null; }

    @Override
    public void onMouseClick(int c, int c1) {
        currentCircle = null;
    }

    @Override
    public void onMouseDrag(int c, int c1) {

        if (!drawCircle) return;

        if (currentCircle == null) {
            originX1 = c;
            originY1 = c1;
            currentCircle = new Circle(c, c1, distance);
        }

        int distance = (int) Math.sqrt((c - originX1) * (c - originX1) + (c1 - originY1) * (c1 - originY1));

        currentCircle.setR(distance);

        currentCircle.setFillColor(model.getCurrentFillColor());
        currentCircle.setStrokeColor(model.getCurrentStrokeColor());
         model.addShape(currentCircle);

    }
}
