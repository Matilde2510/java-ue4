package at.fhhgb.mtd.gop.veccy.shapes;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class Rectangle implements DrawableShape {
    private int x; //ich gebe die Variablen für mein code
    private int y;
    private int width;
    private int height;

    //neue Variablen von dem zweite Uebung.
    private Color fillColor;  //innen den Rectangle
    private Color strokeColor; //linee auß dem Rectangle

    public Color getFillColor() { //methode
        return fillColor;
    }

    public void setFillColor(Color fillColor) {
        this.fillColor = fillColor;
    }

    public Color getStrokeColor() {
        return strokeColor;
    }

    public void setStrokeColor(Color strokeColor) {
        this.strokeColor = strokeColor;
    }

    public Rectangle(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;//diese methode wird jetzt aufgerufen,
        this.width = width;//ich nehme jetzte diese Parameter
        this.height = height;// und ich sage bitte speicher diese Varieblen in dem Konktreten Objekt
        //ich habe in der klasse ein parameter x definiert, deswegen musst du "this.x = x" schreiben
        //das ist so der Rechner kann verstehen auf welche X zuweisen
        //du kannst die auch so schreiben "x = x_wathever"
        //SCHREIB NICHT X=X weil sonst der Rechner versteht nicht welche x meinst du
    }

    //wir wollen eine methoden definier dass der Flacher=area implementiert
    public int area() { //scrivi solo formula dell'oggetto che stai calcolando
        return this.width * this.height; //das ist die Formel die area von der Rectangle zu rechnen
    }

    public Rectangle boundingBox() {
        return new Rectangle(this.x, this.y, this.width, this.height); //create a new rectangle that have the same varibalen als the first
        //bounding box is create so will perfectly touch the line of the circle
        //wir implementiert illustrator und wir wollen die verschieden aufzukoennen

    }

    public boolean isOverlapping(Rectangle other) {
        int xTopRight = x + width;
        int yTopRight = y;

        int yBottomLeft = this.y + this.height;
        int xBottomoLeft = x;

        int xOtherTopRight = other.x + other.width;
        int yOtherTopRight = other.y;

        int yOtherBottomLeft = other.y + other.height;
        int xOtherBottomLeft = other.x;
        //returniert true, wenn this und other überlappen
        //returniert flase, wenn this und other NICHT überlappen
        //unsere koordinate system ist so angebaut:   0,0----→
        //                                               |
        //                                               ↓
        //this.width/x/y/height = the width/height/x/y vom erstem Rectangle
        //other.width/x/y/height = the width/height/x/y vom zweitem Rectangle
        if ((yTopRight > yOtherBottomLeft) ||
                (yBottomLeft < yOtherTopRight)) { //rectangle definieren
            return false;
        }

        if ((xTopRight < xOtherTopRight) ||
                (xBottomoLeft > xOtherTopRight)) {
            return false;
        }

        return true;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    @Override
    public void draw(GraphicsContext graphicsContext) {
        graphicsContext.setFill(this.getFillColor()); //
        graphicsContext.setStroke(this.getStrokeColor());
        graphicsContext.fillRect(this.x, this.y, this.width, this.height); //prima fill e poi strock altrimenti si sovrascrivono
        graphicsContext.strokeRect(this.x, this.y, this.width, this.height);
    }
}
