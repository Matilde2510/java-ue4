package at.fhhgb.mtd.gop.veccy.features;

import at.fhhgb.mtd.gop.veccy.model.CanvasModel;
import at.fhhgb.mtd.gop.veccy.model.NamedFeature;
import at.fhhgb.mtd.gop.veccy.shapes.Circle;
import at.fhhgb.mtd.gop.veccy.shapes.Point;

public class PointFeature implements NamedFeature  {

    private CanvasModel model;

    private Point currentPoint;
    private int originX2;
    private int originY2;


    private boolean drawPoint = false;

    public PointFeature(CanvasModel model) {
        this.model = model;
        originX2 = 0;
        originY2 = 0;
    }

    @Override
    public String getName() { return  "Point"; }

    @Override
    public void onSelect() {
        drawPoint = true;
    }

    @Override
    public void onDeselect() {
        drawPoint = false; currentPoint = null;
    }

    @Override
    public void onMouseClick(int p, int p1) {
        if (!drawPoint) return;

        originX2 = p;
        originY2 = p1;
        currentPoint = new Point(p, p1);

        model.addShape(currentPoint);

        currentPoint = null;

    }

    @Override
    public void onMouseDrag(int p, int p1) {
    }
}
