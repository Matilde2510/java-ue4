package at.fhhgb.mtd.gop.veccy.shapes;

import at.fhhgb.mtd.gop.veccy.VeccyGUI;
import at.fhhgb.mtd.gop.veccy.features.CircleFeature;
import at.fhhgb.mtd.gop.veccy.features.LineFeature;
import at.fhhgb.mtd.gop.veccy.features.PointFeature;
import at.fhhgb.mtd.gop.veccy.features.RectangleFeature;
import at.fhhgb.mtd.gop.veccy.model.CanvasModel;
import javafx.application.Application;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.util.Random;

public class Veccy extends Application {
    public static void main(String[] args) {
        launch();
    }
    @Override
    public void start(Stage stage) throws Exception {

        VeccyGUI veccyGUI = new VeccyGUI(stage);
        CanvasModel model = veccyGUI.getModel();

        model.addFeature(new RectangleFeature(model));
        model.addFeature(new CircleFeature(model));
        model.addFeature(new PointFeature(model));
        model.addFeature(new LineFeature(model));

        /*

        //SEGUE LE COSE IN ORDINE
        //himmel:
        Rectangle rHIMMEL = new Rectangle(0, 0, 2000, 1000); // x = 10+meta raggio cerchio
        rHIMMEL.setFillColor(Color.BLUE); //r=rectangle , set = imposta
        rHIMMEL.setStrokeColor(Color.BLUE);
        model.addShape(rHIMMEL); //das ist um meinen Rectangle zu zeichen

        //serve per posizionare i punti in maniera random

        //sterne:
        Random rnd = new Random();
        for (int n_elementi = 0;  n_elementi < 100; n_elementi ++) {
            Point p = new Point(rnd.nextInt(0, 2000), rnd.nextInt(0, 700)); //bounding serve per non farli andare oltre allo schermo
            p.setFillColor(Color.YELLOW);
            p.setStrokeColor(Color.YELLOW);
            model.addShape(p);
        }

        //moon:
        Circle cMoon = new Circle(1000, 100, 100);
        cMoon.setFillColor(Color.LIGHTYELLOW); //r=rectangle , set = imposta
        cMoon.setStrokeColor(Color.LIGHTYELLOW);
        model.addShape(cMoon); //das ist um meinen Rectangle zu zeichen

        for (int n_elementi = 0;  n_elementi < 5; n_elementi ++) { // n_elementi * 200 -> quel 200 è la distanza
            Rectangle r = new Rectangle(40 + (n_elementi * 205), 500, 50, 500); // x = 10+meta raggio cerchio
            r.setFillColor(Color.web("#6e4318")); //r=rectangle , set = imposta
            r.setStrokeColor(Color.web("#6e4318"));
            model.addShape(r); //das ist um meinen Rectangle zu zeichen

            Circle c = new Circle((n_elementi * 200), 400, 80);
            c.setFillColor(Color.GREEN); //r=rectangle , set = imposta
            c.setStrokeColor(Color.GREEN);
            model.addShape(c); //das ist um meinen Rectangle zu zeichen
        }

        for (int n_elementi = 0;  n_elementi < 150; n_elementi ++) { //sistema y e altezza
            Line l = new Line(10 + (n_elementi * 10), 700 , 10+ (n_elementi * 10), 650); //x2= 1 esce linea verticale e viceversa
            l.setFillColor(Color.GREEN); //r=rectangle , set = imposta
            l.setStrokeColor(Color.GREEN);
            model.addShape(l); //das ist um meinen Rectangle zu zeichen
        }*/

    }


}