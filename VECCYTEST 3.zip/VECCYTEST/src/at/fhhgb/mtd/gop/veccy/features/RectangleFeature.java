package at.fhhgb.mtd.gop.veccy.features;

import at.fhhgb.mtd.gop.veccy.model.CanvasModel;
import at.fhhgb.mtd.gop.veccy.model.NamedFeature;
import at.fhhgb.mtd.gop.veccy.shapes.Rectangle;

public class RectangleFeature implements NamedFeature {
    private final CanvasModel model;

    private Rectangle currentRectangle;

    private boolean drawRectangle = false;
    private int originX;
    private int originY;

    public RectangleFeature(CanvasModel model) {
        this.model = model;
        originX = 0;
        originY = 0;
    }

    @Override
    public String getName() {
        return "Rectangle";
    }

    @Override
    public void onSelect() {
        drawRectangle = true;
    }

    @Override
    public void onDeselect() {
        drawRectangle = false; currentRectangle = null;
    }

    @Override
    public void onMouseClick(int i, int i1) {
        currentRectangle = null;

    }

    @Override
    public void onMouseDrag(int i, int i1) {

        if (!drawRectangle) return;

        if (currentRectangle == null) {
            originX = i;
            originY = i1;
            currentRectangle = new Rectangle(i, i1, 1, 1);
        }

        currentRectangle.setFillColor(model.getCurrentFillColor());
        currentRectangle.setStrokeColor(model.getCurrentStrokeColor());
        currentRectangle.setHeight(i1 - originY);
        currentRectangle.setWidth(i - originX);
        model.addShape(currentRectangle);
    }

}
