package at.fhhgb.mtd.gop.veccy.shapes;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class Circle implements DrawableShape {
    private int x; //ich gebe die Variablen für mein code
    private int y;
    private int r; //raggio

    private Color fillColor;
    private Color strokeColor;

    public Color getFillColor() {
        return fillColor;
    }

    public void setFillColor(Color fillColor) {
        this.fillColor = fillColor;
    }

    public Color getStrokeColor() {
        return strokeColor;
    }

    public void setStrokeColor(Color strokeColor) {
        this.strokeColor = strokeColor;
    }

    public int getR() { //Diese Methoden werden verwendet, um während des Zeichenvorgangs die Details der Formen zu verändern.
        return r;
    }

    public void setR(int r) {
        this.r = r;
    }

    public Circle(int x, int y, int r) {
        this.x = x;
        this.y = y;//diese methode wird jetzt aufgerufen,
        this.r = r;
    }

    //wir wollen eine methoden definiren, dass der Flacher=area implementiert
    public int area(){ //scrivi solo formula dell'oggetto che stai calcolando
            return (int) (Math.PI * r * r); //das ist die Formel die area von der Kreise zu rechnen
    }

    public Rectangle boundingBox(){ //create a new circle that have the same varibalen als the first
        int width = this.r * 2; // calcola width e height = r*2
        int height = this.y * 2; // diesen sind so kann ich dem width und height von dem Bounding Box der Kreise = ein quadrat
        return new Rectangle(this.x, this.y, width, height);

        //bounding box is create so will perfectly touch the line of the circle
        //wir implementiert illustrator und wir wollen die verschieden aufzukoennen
        //WIR SHCREIBEN KEINE LAPPING METHODE, WEIL DER IST SCHON IN DEM RECTANGLE CLASS GESCHRIEBEN

    }

    @Override
    public void draw(GraphicsContext graphicsContext) {
        graphicsContext.setFill(this.getFillColor()); //
        graphicsContext.setStroke(this.getStrokeColor());
        graphicsContext.fillOval(this.x, this.y, this.r*2, this.r*2); //prima fill e poi strock altrimenti si sovrascrivono
        graphicsContext.strokeOval(this.x, this.y, this.r*2, this.r*2);
    }
}
