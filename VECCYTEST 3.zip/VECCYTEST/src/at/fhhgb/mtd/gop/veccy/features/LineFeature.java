package at.fhhgb.mtd.gop.veccy.features;

import at.fhhgb.mtd.gop.veccy.model.CanvasModel;
import at.fhhgb.mtd.gop.veccy.model.NamedFeature;
import at.fhhgb.mtd.gop.veccy.shapes.Circle;
import at.fhhgb.mtd.gop.veccy.shapes.Line;
import at.fhhgb.mtd.gop.veccy.shapes.Point;
import at.fhhgb.mtd.gop.veccy.shapes.Rectangle;

public class LineFeature implements NamedFeature {

    private CanvasModel model;

    private Line currentLine;
    private int originX3;
    private int originY3;


    private boolean drawLine = false;

    public LineFeature(CanvasModel model) {
        this.model = model;
        originX3 = 0;
        originY3 = 0;
    }

    @Override
    public String getName() { return "Line"; }

    @Override
    public void onSelect() { drawLine = true; }

    @Override
    public void onDeselect() { drawLine = false; currentLine = null; }

    @Override
    public void onMouseClick(int l, int l1) { //x,y
        currentLine = null;
    }

    @Override
    public void onMouseDrag(int l, int l1) {
        if (!drawLine) return;

        if (currentLine == null) {
            originX3 = l;
            originY3 = l1;
            currentLine = new Line(l, l1, l, l1);
        }

        currentLine.setX2(l);
        currentLine.setY2(l1);

        currentLine.setFillColor(model.getCurrentFillColor());
        currentLine.setStrokeColor(model.getCurrentStrokeColor());
        model.addShape(currentLine);
    }
}
