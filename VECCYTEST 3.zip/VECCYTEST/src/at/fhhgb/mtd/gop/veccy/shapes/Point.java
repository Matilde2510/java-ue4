package at.fhhgb.mtd.gop.veccy.shapes;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class Point implements DrawableShape {
    private int x; //ich gebe die Variablen für mein code
    private int y;

    private Color fillColor;

    private Color strokeColor;

    public Color getFillColor() {
        return fillColor;
    }

    public void setFillColor(Color fillColor) {
        this.fillColor = fillColor;
    }

    public Color getStrokeColor() {
        return strokeColor;
    }

    public void setStrokeColor(Color strokeColor) {
        this.strokeColor = strokeColor;
    }

    public Point(int x, int y) {
        this.x = x;
        this.y = y;//diese methode wird jetzt aufgerufen,
    }

    //wir wollen eine methoden definier dass der Flacher=area implementiert
    public int area() { //scrivi solo formula dell'oggetto che stai calcolando
        return 0; //weil ein punkt keine area hat, schreibe ich einfach 1
    }

    public Rectangle boundingBox() {
        //rectangle zuruck geben
        Rectangle rectangle = new Rectangle(x,y,1,1);
        return rectangle;
    }

    @Override
    public void draw(GraphicsContext graphicsContext) {
        graphicsContext.setFill(this.getFillColor()); //
        graphicsContext.setStroke(this.getStrokeColor());
        graphicsContext.fillRect(this.x, this.y, 1,1); //prima fill e poi strock altrimenti si sovrascrivono
        graphicsContext.strokeRect(this.x, this.y, 1,1);
    }
}
