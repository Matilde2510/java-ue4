package at.fhhgb.mtd.gop.veccy.shapes;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class Line implements DrawableShape {
    private int x; //ich gebe die Variablen für mein code
    private int y;
    private int x2;
    private int y2;

    private Color fillColor;
    private Color strokeColor;

    public Color getFillColor() {
        return fillColor;
    }

    public void setFillColor(Color fillColor) {
        this.fillColor = fillColor;
    }

    public Color getStrokeColor() {
        return strokeColor;
    }

    public void setStrokeColor(Color strokeColor) {
        this.strokeColor = strokeColor;
    }


    public Line(int x, int y, int x2, int y2) {
        this.x = x;
        this.y = y;//diese methode wird jetzt aufgerufen,
        this.x2 = x2;
        this.y2 = y2;
    }

    public void setX2(int x2) {
        this.x2 = x2;
    }

    public void setY2(int y2) {
        this.y2 = y2;
    }

    //wir wollen eine methoden definiren, dass der Flacher=area implementiert
    public int area() { //scrivi solo formula dell'oggetto che stai calcolando
        return 0; //weil eine linee keine areqa hat, schreibe ich einfach 1
    }

    public Rectangle boundingBox() {
        int height = Math.abs(y2 - y);
        int weidth = Math.abs(x2 - x);

        if (y2 < y) {
            return new Rectangle(x, y2, weidth, height); // quando la linea va subito allora mi crea un rettangolo come lo volevo nel pimo codice
        }

        //create a new circle that have the same varibalen als the first
        //bounding box is create so will perfectly touch the line of the circle
        //wir implementiert illustrator und wir wollen die verschieden aufzukoennen

         //
        return new Rectangle(x, y, weidth, height);
    }

    @Override
    public void draw(GraphicsContext graphicsContext) {
        graphicsContext.setFill(this.getFillColor()); //
        graphicsContext.setStroke(this.getStrokeColor());
        graphicsContext.strokeLine(this.x, this.y, this.x2, this.y2); //linea vera e propria
        //graphicsContext.fillRect(this.x, this.y, 1, 1); //prima fill e poi strock altrimenti si sovrascrivono
        //graphicsContext.strokeRect(this.x, this.y, this.x2, this.y2);
    }
}
