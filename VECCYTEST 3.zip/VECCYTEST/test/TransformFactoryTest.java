import at.fhhgb.mtd.gop.math.Matrix3;
import at.fhhgb.mtd.gop.math.Vector3;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TransformFactoryTest {

    @Test
    void createTranslation() {
        Vector3 v = new Vector3(new double[]{5.0, 5.0, 1.0});
        Matrix3 t = TransformFactory.createTranslation(2, 3);
        Vector3 v_t = t.mult(v);

        assertArrayEquals(new double[]{7.0, 8.0, 1.0}, v_t.getValues(), 0.1);
    }

    @Test
    void createRotation() {
        Vector3 v = new Vector3(new double[]{1.0, 0.0, 1.0});
        Matrix3 t = TransformFactory.createRotation(Math.PI/2);
        Vector3 v_t = t.mult(v);

        assertArrayEquals(new double[]{0.0, 1.0, 1.0}, v_t.getValues(), 0.1);
    }

    @Test
    void createHorizontalMirroring() {
        Vector3 v = new Vector3(new double[]{1.0, 1.0, 1.0});
        Matrix3 t = TransformFactory.createHorizontalMirroring();
        Vector3 v_t = t.mult(v);

        assertArrayEquals(new double[]{-1.0, 1.0, 1.0}, v_t.getValues(), 0.1);
    }

    @Test
    void createVerticalMirroring() {
        Vector3 v = new Vector3(new double[]{1.0, 1.0, 1.0});
        Matrix3 t = TransformFactory.createVerticalMirroring();
        Vector3 v_t = t.mult(v);

        assertArrayEquals(new double[]{1.0, -1.0, 1.0}, v_t.getValues(), 0.1);
    }

    @Test
    void createScaling() {
        Vector3 v = new Vector3(new double[]{4.0, 2.0, 1.0});
        Matrix3 t = TransformFactory.createScaling(4, 7);
        Vector3 v_t = t.mult(v);

        assertArrayEquals(new double[]{16.0, 14.0, 1.0}, v_t.getValues(), 0.1);
    }
}