package at.fhhgb.mtd.gop.veccy.shapes;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.concurrent.RecursiveAction;

import static org.junit.jupiter.api.Assertions.*;

class RectangleTest {


    @Test
    void area() {
        Rectangle rectangle = new Rectangle(0,0,42,12);
        assertEquals(504,rectangle.area());
        assertNotEquals(123,rectangle.area());
    }

    @Test
    void boundingBox() {
        Rectangle rectangle = new Rectangle(0,0,42,12);
        Rectangle bb = rectangle.boundingBox();
    }

    @Test
    void isOverlapping() {
        // test 1
        Rectangle rectangle1 = new Rectangle(3, 4, 30, 40);
        Rectangle rectangle2 = new Rectangle(2, 3, 100, 10);

        assertFalse(rectangle1.isOverlapping(rectangle2));

        // test 2
        rectangle1 = new Rectangle(2000, 10, 30, 40);
        rectangle2 = new Rectangle(2010, 7, 50, 30);

        assertFalse(rectangle1.isOverlapping(rectangle2));

    }
}