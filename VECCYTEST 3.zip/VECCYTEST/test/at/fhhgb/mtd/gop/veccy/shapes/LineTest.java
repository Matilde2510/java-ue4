package at.fhhgb.mtd.gop.veccy.shapes;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class LineTest {

    @Test
    void area() {
        Line line = new Line(2,2,4,4);
        assertEquals(0, line.area());
    }

    @Test
    void boundingBox() {
        Line line = new Line(2, 2, 4, 4);
        Line line2 = new Line(5,5,8,8);

        Rectangle lineBoundings = line.boundingBox();
        assertFalse(lineBoundings.isOverlapping(line2.boundingBox()));

        Line line1 = new Line (3, 2, 10,10);
        assertTrue(line1.boundingBox().isOverlapping(lineBoundings));
    }
}