package at.fhhgb.mtd.gop.veccy.shapes;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PointTest {

    @Test
    void area() {
        Point point = new Point(2,2);
        assertEquals(0, point.area());
    }

    @Test
    void boundingBox() {
        Point point = new Point(2,2);
        Point point2 = new Point(4,4);

        Rectangle pointBoundings = point.boundingBox();
        assertEquals(2, pointBoundings.getX()); //assert = mann moechte sicherstellen -> wir moechten wissen ob die gleichn sind
        assertEquals(2, pointBoundings.getY()); //erste parameter ist was du erwatest und zweite ist was der code dir zuruck gibt
        assertEquals(1, pointBoundings.getWidth());
        assertEquals(1, pointBoundings.getHeight());

        Point point1 = new Point (10,10);
        assertFalse(point1.boundingBox().isOverlapping(pointBoundings));
    }
}