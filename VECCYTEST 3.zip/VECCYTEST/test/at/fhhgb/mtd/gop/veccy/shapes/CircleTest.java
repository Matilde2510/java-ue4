package at.fhhgb.mtd.gop.veccy.shapes;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CircleTest {

    @Test
    void area() {
        Circle circle = new Circle(2, 3, 4);

        assertEquals(50, circle.area());
    }

    @Test
    void boundingBox() {

        Circle circle = new Circle(2, 3, 4);
        Circle circle2 = new Circle(2, 3, 1);

        Rectangle circleBoundings = circle.boundingBox();
        assertTrue(circleBoundings.isOverlapping(circle2.boundingBox()));

        Circle circle1 = new Circle(3, 2, 10);
        assertTrue(circle1.boundingBox().isOverlapping(circleBoundings));
    }
}