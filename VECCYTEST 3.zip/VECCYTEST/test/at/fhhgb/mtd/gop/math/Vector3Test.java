package at.fhhgb.mtd.gop.math;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

public class Vector3Test {

    @Test
    void getValues() {
//das ist unoetig, weil ich es schon bei matrix ist~
    }
}
