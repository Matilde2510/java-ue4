package at.fhhgb.mtd.gop.math;

import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

public class Matrix3Test {

    @Test
    void mult() {

        //CHIEDI AL PROF PERCHE PRIMO ESEMPIO NON FUNZIA
        Matrix3 m1 = new Matrix3(); //hinterground der Konstrukt aufgerufen
        Matrix3 m2 = new Matrix3(new double[][]{
                {1.0, 0.0, 0.0},
                {0.0, 2.0, 0.0},
                {0.0, 0.0, 3.0}
        });
        var res = m1.mult(m2);
        //copia asert true
        assertTrue(Arrays.deepEquals(m1.getValues(), m2.getValues()));
        //assertNotEquals(res, m2); //il risultato è uguale a m2 perchè m1 ha i valori 1

//prova due:
        Matrix3 m3 = new Matrix3(new double[][]{
                {1.0, 0.0, 0.0},
                {0.0, 2.0, 0.0},
                {0.0, 0.0, 3.0}
        });

        Matrix3 m4 = new Matrix3(new double[][]{
                {4.0, 0.0, 0.0},
                {0.0, 5.0, 0.0},
                {0.0, 0.0, 6.0}
        });
        assertNotEquals(m3.mult(m4), new double[][]{ //copia assert ture
                {4.0, 0.0, 0.0},
                {0.0, 10.0, 0.0},
                {0.0, 0.0, 18.0}
        });

    }
}
